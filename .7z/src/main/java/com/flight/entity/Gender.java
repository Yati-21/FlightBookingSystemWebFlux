package com.flight.entity;

public enum Gender {
    M, 
    F, 
    O //other
}