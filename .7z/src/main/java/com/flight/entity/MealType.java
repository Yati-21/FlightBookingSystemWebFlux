package com.flight.entity;

public enum MealType {
    VEG,
    NON_VEG
}