package com.flight.entity;

public enum AirportCode 
{
    DEL,   
    BOM,
    BLR,
    MAA,
    HYD,
    CCU,
    GOI,
    PNQ,
    AMD,
    COK;
}
