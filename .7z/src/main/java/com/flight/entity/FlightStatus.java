package com.flight.entity;

public enum FlightStatus {
    SCHEDULED,
    CANCELLED
}